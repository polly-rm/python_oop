from project_restaurant.food.food import Food

class MainDish(Food):
    pass
