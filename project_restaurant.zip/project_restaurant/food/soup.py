from project_restaurant.food.starter import Starter

class Soup(Starter):
    pass
