from project_restaurant.beverage.beverage import Beverage

class ColdBeverage(Beverage):
    pass
