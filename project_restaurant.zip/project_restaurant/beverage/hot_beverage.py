from project_restaurant.beverage.beverage import Beverage

class HotBeverage(Beverage):
    pass
