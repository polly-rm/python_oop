from project_zoo_2.mammal import Mammal

class Gorilla(Mammal):
    pass