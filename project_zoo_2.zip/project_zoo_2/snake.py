from project_zoo_2.reptile import Reptile

class Snake(Reptile):
    pass