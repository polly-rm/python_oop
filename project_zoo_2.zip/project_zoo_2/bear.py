from project_zoo_2.mammal import Mammal

class Bear(Mammal):
    pass