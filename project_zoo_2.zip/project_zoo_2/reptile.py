from project_zoo_2.animal import Animal

class Reptile(Animal):
    pass

