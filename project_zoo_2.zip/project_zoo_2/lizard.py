from project_zoo_2.reptile import Reptile

class Lizard(Reptile):
    pass