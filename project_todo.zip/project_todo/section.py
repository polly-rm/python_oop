from project_todo.task import Task
class Section:
    def __init__(self, name):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if new_task in self.tasks:
            return f"Task is already in the section {self.name}"
        self.tasks.append(new_task)
        return f"Task {new_task.details()} is added to the section"

    def complete_task(self, task_name: str):
        task_to_complete_list = [t for t in self.tasks if t.name == task_name]
        if task_to_complete_list:
            task_to_complete = task_to_complete_list[0]
            task_to_complete.completed = True
            return f"Completed task {task_name}"
        return f"Could not find task with the name {task_name}"

    def clean_section(self):
        uncompleted_tasks = [t for t in self.tasks if not t.completed]
        amount_of_removed_tasks = len(self.tasks) - len(uncompleted_tasks)
        self.tasks = uncompleted_tasks
        return f"Cleared {amount_of_removed_tasks} tasks."

    def view_section(self):
        res = f"Section {self.name}:\n"
        for task in self.tasks:
            res += f"{task.details()}\n"
        return res


