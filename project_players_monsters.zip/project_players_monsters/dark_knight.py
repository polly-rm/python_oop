from project_players_monsters.knight import Knight

class DarkKnight(Knight):
    pass