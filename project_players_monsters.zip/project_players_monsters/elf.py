from project_players_monsters.hero import Hero

class Elf(Hero):
    pass

