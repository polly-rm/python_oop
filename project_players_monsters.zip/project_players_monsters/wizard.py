from project_players_monsters.hero import Hero

class Wizard(Hero):
    pass