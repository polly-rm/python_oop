from project_players_monsters.elf import Elf

class MuseElf(Elf):
    pass