from project_need_for_speed.motorcycle import Motorcycle

class CrossMotorcycle(Motorcycle):
    pass