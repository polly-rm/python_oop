from project_need_for_speed.car import Car

class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10