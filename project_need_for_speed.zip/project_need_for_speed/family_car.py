from project_need_for_speed.car import Car

class FamilyCar(Car):
    pass