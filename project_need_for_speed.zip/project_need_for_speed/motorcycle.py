from project_need_for_speed.vehicle import Vehicle

class Motorcycle(Vehicle):
    pass