from project_pokemon.pokemon import Pokemon
class Trainer:
    def __init__(self, name):
        self.name = name
        self.pokemon = []

    def add_pokemon(self, pokemon: Pokemon):
        if pokemon not in self.pokemon:
            self.pokemon.append(pokemon)
            return f"Caught {pokemon.name} with health {pokemon.health}"
        return "This pokemon is already caught"

    def release_pokemon(self, pokemon_name: str):
        pokemon_to_remove = [p for p in self.pokemon if p.name == pokemon_name]
        if pokemon_to_remove:
            self.pokemon.remove(pokemon_to_remove[0])
            return f"You have released {pokemon_name}"
        else:
            return "Pokemon is not caught"

    def trainer_data(self):
        res = f"Pokemon Trainer {self.name}\n"
        res += f"Pokemon count {len(self.pokemon)}\n"
        for p in self.pokemon:
            res += f"- {p.pokemon_details()}\n"
        return res



