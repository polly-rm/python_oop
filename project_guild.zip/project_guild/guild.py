from project_guild.player import Player
class Guild:
    def __init__(self, name):
        self.name = name
        self.players_list = []

    def assign_player(self, player: Player):
        if not player.guild == self.name and not player.guild == "Unaffiliated":
            return f"Player {player.name} is in another guild."

        current_players = [p for p in self.players_list if p == player]
        if current_players:
            return f"Player {player.name} is already in the guild."
        self.players_list.append(player)
        player.guild = self.name
        return f"Welcome player {player.name} to the guild {self.name}"

    def kick_player(self, player_name: str):
        player_to_kick = [p for p in self.players_list if p.name == player_name]
        if player_to_kick:
            self.players_list.remove(player_to_kick[0])
            player_to_kick[0].guild = "Unaffiliated"
            return f"Player {player_name} has been removed from the guild."
        else:
            return f"Player {player_name} is not in the guild."

    def guild_info(self):
        res = f"Guild: {self.name}\n"
        for p in self.players_list:
            res += f"{p.player_info()}"
        return res







