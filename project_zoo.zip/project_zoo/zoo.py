class Zoo:
    def __init__(self, name, budget, animal_capacity, workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []

    def add_animal(self, animal, price):
        if price <= self.__budget and len(self.animals) < self.__animal_capacity:
            self.animals.append(animal)
            self.__budget -= price
            return f"{animal.name} the {animal.__class__.__name__} added to the zoo"
        elif len(self.animals) < self.__animal_capacity and price > self.__budget:
            return "Not enough budget"
        else:
            return "Not enough space for animal"

    def hire_worker(self, worker):
        if len(self.workers) < self.__workers_capacity:
            self.workers.append(worker)
            return f"{worker.name} the {worker.__class__.__name__} hired successfully"
        return "Not enough space for worker"

    def fire_worker(self, worker_name):
        worker_to_fire_list = [w for w in self.workers if w.name == worker_name]
        if worker_to_fire_list:
            worker_to_fire = worker_to_fire_list[0]
            self.workers.remove(worker_to_fire)
            return f"{worker_name} fired successfully"
        return f"There is no {worker_name} in the zoo"

    def pay_workers(self):
        workers_salary_sum = sum([w.salary for w in self.workers])
        if self.__budget >= workers_salary_sum:
            self.__budget -= workers_salary_sum
            return f"You payed your workers. They are happy. Budget left: {self.__budget}"
        return "You have no budget to pay your workers. They are unhappy"

    def tend_animals(self):
        animals_needs_sum = sum([a.get_needs() for a in self.animals])
        if self.__budget >= animals_needs_sum:
            self.__budget -= animals_needs_sum
            return f"You tended all the animals. They are happy. Budget left: {self.__budget}"
        return f"You have no budget to tend the animals. They are unhappy."

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        lions_list = [a for a in self.animals if a.__class__.__name__ == "Lion"]
        tigers_list = [a for a in self.animals if a.__class__.__name__ == "Tiger"]
        cheetahs_list = [a for a in self.animals if a.__class__.__name__ == "Cheetah"]

        result = f"You have {len(self.animals)} animals\n"
        result += f"----- {len(lions_list)} Lions:\n"
        for l in lions_list:
            result += f"{l.__repr__()}\n"

        result += f"----- {len(tigers_list)} Tigers:\n"
        for t in tigers_list:
            result += f"{t.__repr__()}\n"

        result += f"----- {len(cheetahs_list)} Cheetahs:\n"
        for c in cheetahs_list[:-1]:
            result += f"{c.__repr__()}\n"
        last_c = cheetahs_list[-1]
        result += f"{last_c.__repr__()}"

        return result

    def workers_status(self):
        keepers_list = [w for w in self.workers if w.__class__.__name__ == "Keeper"]
        caretakers_list = [w for w in self.workers if w.__class__.__name__ == "Caretaker"]
        vets_list = [w for w in self.workers if w.__class__.__name__ == "Vet"]

        result = f"You have {len(self.workers)} workers\n"
        result += f"----- {len(keepers_list)} Keepers:\n"
        for k in keepers_list:
            result += f"{k.__repr__()}\n"

        result += f"----- {len(caretakers_list)} Caretakers:\n"
        for c in caretakers_list:
            result += f"{c.__repr__()}\n"

        result += f"----- {len(vets_list)} Vets:\n"
        for v in vets_list[:-1]:
            result += f"{v.__repr__()}\n"
        last_vet = vets_list[-1]
        result += f"{last_vet.__repr__()}"

        return result










        
        
        