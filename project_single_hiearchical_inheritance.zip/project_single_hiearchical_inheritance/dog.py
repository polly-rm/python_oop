from project_single_hiearchical_inheritance.animal import Animal
class Dog(Animal):
    @staticmethod
    def bark():
        return "barking..."

