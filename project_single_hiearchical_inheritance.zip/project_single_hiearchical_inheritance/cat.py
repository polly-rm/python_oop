from project_single_hiearchical_inheritance.animal import Animal

class Cat(Animal):
    @staticmethod
    def meow():
        return "meowing..."